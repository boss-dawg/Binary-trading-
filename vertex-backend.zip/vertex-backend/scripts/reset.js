'use strict';
// Deletes the database and recreates it with fresh seed data.
const fs = require('node:fs');
const { DB_PATH } = require('../src/config');

for (const suffix of ['', '-wal', '-shm']) fs.rmSync(DB_PATH + suffix, { force: true });
const { seedIfEmpty, DEMO } = require('../src/seed');
seedIfEmpty();
console.log(`Database reset at ${DB_PATH}\nDemo login: ${DEMO.email} / ${DEMO.password}`);
