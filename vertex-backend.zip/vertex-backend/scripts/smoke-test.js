'use strict';
// End-to-end smoke test: boots the server on a temp database and exercises the API + WebSocket.
const { spawn } = require('node:child_process');
const os = require('node:os');
const path = require('node:path');
const fs = require('node:fs');

const PORT = 3900 + Math.floor(Math.random() * 90);
const BASE = `http://localhost:${PORT}`;
const DB = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'vertex-')), 'test.db');
const ADMIN_KEY = 'test-admin-key-123';

let passed = 0, failed = 0;
const check = (name, cond, extra = '') => {
  if (cond) { passed++; console.log(`  ok   ${name}`); }
  else { failed++; console.log(`  FAIL ${name} ${extra}`); }
};

async function api(method, url, { token, body, headers } = {}) {
  const res = await fetch(BASE + url, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}), ...headers },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, data: await res.json() };
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const near = (a, b, tol = 1e-6) => Math.abs(a - b) <= tol * Math.max(1, Math.abs(b));

async function main() {
  const child = spawn(process.execPath, ['--no-warnings', path.join(__dirname, '..', 'src', 'server.js')], {
    env: { ...process.env, PORT, DB_PATH: DB, TICK_MS: '100', ADMIN_KEY, DEPOSIT_BANK_ACCOUNT: '0223060087462', DEPOSIT_CURRENCY: 'USD' },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let serverLog = '';
  child.stdout.on('data', (d) => (serverLog += d));
  child.stderr.on('data', (d) => (serverLog += d));

  try {
    for (let i = 0; i < 50; i++) {
      try { if ((await fetch(BASE + '/api/health')).ok) break; } catch { /* not up yet */ }
      await sleep(100);
    }

    console.log('market data');
    const health = await api('GET', '/api/health');
    check('health', health.status === 200 && health.data.markets === 8);
    const mk = await api('GET', '/api/markets');
    check('8 markets with sparkline', mk.data.markets.length === 8 && mk.data.markets[0].spark.length === 24);
    const gain = await api('GET', '/api/markets?sort=gainers');
    check('gainers sorted', gain.data.markets[0].change24h >= gain.data.markets[7].change24h);
    for (const [tf, n] of [['1D', 96], ['1W', 168], ['1M', 120], ['3M', 180], ['1Y', 365]]) {
      const c = await api('GET', `/api/markets/BTC/candles?tf=${tf}`);
      check(`candles ${tf} = ${n}`, c.data.candles.length === n);
    }
    const cs = (await api('GET', '/api/markets/ETH/candles?tf=1D')).data.candles;
    check('candles ascending + valid OHLC', cs.every((c, i) => (i === 0 || c.t > cs[i - 1].t) && c.h >= Math.max(c.o, c.c) && c.l <= Math.min(c.o, c.c)));
    const book = await api('GET', '/api/markets/BTC/book');
    check('order book 11 levels per side', book.data.asks.length === 11 && book.data.bids.length === 11 && book.data.asks[0].price > book.data.bids[0].price);
    check('unknown market -> 404', (await api('GET', '/api/markets/NOPE')).status === 404);
    check('bad timeframe -> 400', (await api('GET', '/api/markets/BTC/candles?tf=5Y')).status === 400);

    console.log('auth');
    check('protected route without token -> 401', (await api('GET', '/api/portfolio')).status === 401);
    check('bad password -> 401', (await api('POST', '/api/auth/login', { body: { email: 'demo@vertex.app', password: 'wrongpass1' } })).status === 401);
    const demo = await api('POST', '/api/auth/login', { body: { email: 'demo@vertex.app', password: 'demo1234' } });
    check('demo login', demo.status === 200 && !!demo.data.token);
    const dp = await api('GET', '/api/portfolio', { token: demo.data.token });
    check('demo has 3 positions + 1 open order', dp.data.positions.length === 3 && dp.data.openOrders === 1);
    check('demo USD has locked funds for resting order', dp.data.balances.find((b) => b.asset === 'USD').locked > 16000);
    check('weak password rejected', (await api('POST', '/api/auth/register', { body: { email: 'a@b.co', password: 'short' } })).status === 400);
    const email = `t${Date.now()}@example.com`;
    const reg = await api('POST', '/api/auth/register', { body: { email, password: 'password123', name: 'Tester' } });
    check('register -> 201', reg.status === 201);
    check('duplicate email -> 409', (await api('POST', '/api/auth/register', { body: { email, password: 'password123' } })).status === 409);
    const token = reg.data.token;
    check('/api/me', (await api('GET', '/api/me', { token })).data.user.email === email);

    console.log('spot orders');
    const usd0 = (await api('GET', '/api/portfolio', { token })).data.balances.find((b) => b.asset === 'USD').amount;
    check('new account starts with 100000 USD', usd0 === 100000);
    const buy = await api('POST', '/api/orders', { token, body: { symbol: 'BTC', side: 'buy', type: 'market', amount: 0.1 } });
    check('market buy filled', buy.status === 201 && buy.data.order.status === 'filled');
    const o = buy.data.order;
    const pf = (await api('GET', '/api/portfolio', { token })).data;
    const usd1 = pf.balances.find((b) => b.asset === 'USD').amount;
    check('USD debited by notional + 0.05% fee', near(usd0 - usd1, o.amount * o.avgPrice + o.fee, 1e-6));
    check('BTC credited', near(pf.balances.find((b) => b.asset === 'BTC').amount, 0.1));
    check('trade recorded', (await api('GET', '/api/trades', { token })).data.trades.length === 1);
    check('oversized buy rejected', (await api('POST', '/api/orders', { token, body: { symbol: 'BTC', side: 'buy', type: 'market', amount: 1000 } })).status === 400);
    check('sell more than owned rejected', (await api('POST', '/api/orders', { token, body: { symbol: 'BTC', side: 'sell', type: 'market', amount: 5 } })).status === 400);
    check('invalid side rejected', (await api('POST', '/api/orders', { token, body: { symbol: 'BTC', side: 'hold', amount: 1 } })).status === 400);
    check('negative amount rejected', (await api('POST', '/api/orders', { token, body: { symbol: 'BTC', side: 'buy', amount: -1 } })).status === 400);

    const px = (await api('GET', '/api/markets/BTC')).data;
    const lim = await api('POST', '/api/orders', { token, body: { symbol: 'BTC', side: 'buy', type: 'limit', amount: 0.05, price: Math.round(px.price * 0.9) } });
    check('resting limit buy is open', lim.data.order.status === 'open');
    const locked = (await api('GET', '/api/portfolio', { token })).data.balances.find((b) => b.asset === 'USD');
    check('limit buy locks USD', locked.locked > 0 && locked.available < locked.amount);
    const can = await api('DELETE', `/api/orders/${lim.data.order.id}`, { token });
    check('cancel releases lock', can.data.order.status === 'cancelled' && (await api('GET', '/api/portfolio', { token })).data.balances.find((b) => b.asset === 'USD').locked === 0);
    check('cancelling twice -> 409', (await api('DELETE', `/api/orders/${lim.data.order.id}`, { token })).status === 409);
    check("can't cancel another user's order", (await api('DELETE', '/api/orders/1', { token })).status === 404);
    check('buy stop below market rejected', (await api('POST', '/api/orders', { token, body: { symbol: 'BTC', side: 'buy', type: 'stop', amount: 0.01, stopPrice: px.price * 0.5 } })).status === 400);

    // bracket the market with a buy limit just below and a sell limit just above: the next price move must cross one
    const quote = (await api('GET', '/api/markets/BTC')).data;
    const sellLim = await api('POST', '/api/orders', { token, body: { symbol: 'BTC', side: 'sell', type: 'limit', amount: 0.05, price: quote.bid * 1.00005 } });
    const buyLim = await api('POST', '/api/orders', { token, body: { symbol: 'BTC', side: 'buy', type: 'limit', amount: 0.05, price: quote.ask * 0.99995 } });
    check('bracketing limit orders are resting', sellLim.data.order.status === 'open' && buyLim.data.order.status === 'open');
    let hit = null;
    for (let i = 0; i < 100 && !hit; i++) {
      await sleep(100);
      const list = (await api('GET', '/api/orders?status=filled', { token })).data.orders;
      hit = list.find((x) => x.id === sellLim.data.order.id || x.id === buyLim.data.order.id);
    }
    check('engine filled a resting limit order on a later tick', !!hit);
    for (const o2 of [sellLim.data.order, buyLim.data.order]) await api('DELETE', `/api/orders/${o2.id}`, { token }); // cleanup (409 for the filled one is fine)
    const settled = (await api('GET', '/api/portfolio', { token })).data;
    check('no funds left locked after fill + cancel', settled.balances.every((b) => b.locked === 0), JSON.stringify(settled.balances));

    console.log('leveraged positions');
    const open = await api('POST', '/api/positions', { token, body: { symbol: 'ETH', side: 'long', size: 1, leverage: 10 } });
    check('open long 10x', open.status === 201 && near(open.data.position.liqPrice, open.data.position.entryPrice * 0.91, 1e-9));
    check('leverage above max rejected', (await api('POST', '/api/positions', { token, body: { symbol: 'ETH', side: 'long', size: 1, leverage: 100 } })).status === 400);
    const closed = await api('POST', `/api/positions/${open.data.position.id}/close`, { token });
    check('close position', closed.data.position.status === 'closed');
    check('closing twice -> 409', (await api('POST', `/api/positions/${open.data.position.id}/close`, { token })).status === 409);

    console.log('deposits');
    const info = await api('GET', '/api/deposit-info');
    check('deposit info shows bank account', info.data.enabled && info.data.bankAccount === '0223060087462');
    const dep = await api('POST', '/api/deposits', { token, body: { amount: 250 } });
    check('deposit request is pending with a reference', dep.status === 201 && dep.data.deposit.status === 'pending' && dep.data.deposit.reference.startsWith('VTX-'));
    const before = (await api('GET', '/api/portfolio', { token })).data.balances.find((b) => b.asset === 'USD').amount;
    check('pending deposit does NOT credit balance', (await api('GET', '/api/portfolio', { token })).data.balances.find((b) => b.asset === 'USD').amount === before);
    check('admin confirm needs the key', (await api('POST', `/api/admin/deposits/${dep.data.deposit.id}/confirm`, { token })).status === 403);
    const conf = await api('POST', `/api/admin/deposits/${dep.data.deposit.id}/confirm`, { headers: { 'X-Admin-Key': ADMIN_KEY } });
    check('admin confirm credits balance', conf.data.deposit.status === 'confirmed' && (await api('GET', '/api/portfolio', { token })).data.balances.find((b) => b.asset === 'USD').amount > before + 249);
    check('confirming twice -> 409', (await api('POST', `/api/admin/deposits/${dep.data.deposit.id}/confirm`, { headers: { 'X-Admin-Key': ADMIN_KEY } })).status === 409);

    console.log('websocket');
    const msgs = [];
    const sock = new WebSocket(`ws://localhost:${PORT}/ws`);
    await new Promise((res, rej) => { sock.onopen = res; sock.onerror = rej; });
    sock.onmessage = (e) => msgs.push(JSON.parse(e.data));
    sock.send(JSON.stringify({ type: 'subscribe', symbol: 'ETH' }));
    sock.send(JSON.stringify({ type: 'auth', token }));
    await sleep(600);
    const types = new Set(msgs.map((m) => m.type));
    check('ws hello + tick + book + candle', ['hello', 'tick', 'book', 'candle'].every((t) => types.has(t)));
    check('ws auth ok + portfolio pushed', msgs.some((m) => m.type === 'auth' && m.ok) && types.has('portfolio'));
    check('ws book is for subscribed symbol', msgs.filter((m) => m.type === 'book').some((m) => m.symbol === 'ETH'));
    sock.close();

    check('unknown route -> 404', (await api('GET', '/api/nope')).status === 404);
  } finally {
    child.kill('SIGTERM');
    if (failed) console.log('\n--- server log ---\n' + serverLog);
  }
  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
}

main().catch((err) => { console.error(err); process.exit(1); });
