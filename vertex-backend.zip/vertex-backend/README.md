# Vertex backend

REST API + WebSocket feed + SQLite database for the Vertex trading terminal.
**No npm packages needed**: it uses only Node built-ins (`node:http`, `node:sqlite`, `node:crypto`). Requires Node 22.13+.

```bash
npm start              # http://localhost:3000  (creates data/vertex.db and seeds it on first run)
npm test               # boots a throwaway server and runs 50+ end-to-end checks
npm run reset          # wipe the database and reseed
```

Demo login (seeded): `demo@vertex.app` / `demo1234`

## Important: what this is and isn't

- **Prices are simulated.** The market engine is a random walk (same idea as the frontend's `tick()`), stored as candles in the database. It is **not** connected to a real exchange.
- Orders, positions and balances are real database records with proper accounting (fees, locked funds, liquidation), but they trade against the simulator, i.e. **paper trading**.
- If you want real trading, replace `src/market.js` with a real price feed and add a licensed broker/exchange integration.

## Deposits (bank transfer)

Money can't be moved by this server, and it can't see your bank account. The flow is manual and safe:

1. User calls `POST /api/deposits {amount}` and gets a **reference code** (`VTX-XXXXXXXXXX`) plus your bank details.
2. User transfers the money to the account and puts the reference in the payment description.
3. You check your bank statement, then credit the user: `POST /api/admin/deposits/:id/confirm` with header `X-Admin-Key: <ADMIN_KEY>`. (`/reject` declines it.)
   A deposit is only credited once, and never before you confirm it.

Configure it with environment variables (see `.env.example`):

```bash
DEPOSIT_BANK_ACCOUNT=0223060087462 DEPOSIT_BANK_NAME="Your Bank" DEPOSIT_ACCOUNT_NAME="Your Name" \
ADMIN_KEY="$(openssl rand -hex 24)" STARTING_USD=0 npm start
```

Set `STARTING_USD=0` if users should only trade what they deposit (the default gives new accounts 100,000 free paper dollars).
Before taking real money from the public, check the licensing rules for your country: holding customer funds and offering trading usually requires a licence, and showing simulated prices as if they were real would be misleading. A payment provider (M-Pesa, Flutterwave, Stripe, etc.) is the usual way to automate deposits.

## REST API

All bodies are JSON. Authenticated routes need `Authorization: Bearer <token>`.

| Method & path | Auth | Notes |
|---|---|---|
| `GET /api/health` | | |
| `GET /api/markets?sort=gainers\|losers&q=` | | price, bid/ask, 24h change/high/low/volume, sparkline |
| `GET /api/markets/:symbol` | | |
| `GET /api/markets/:symbol/candles?tf=1D\|1W\|1M\|3M\|1Y&limit=` | | `[{t,o,h,l,c,v}]`, oldest first |
| `GET /api/markets/:symbol/book` | | `asks` / `bids`, best first, with cumulative `total` |
| `POST /api/auth/register` `{email,password,name?}` | | returns `{token,user}` |
| `POST /api/auth/login` `{email,password}` | | |
| `POST /api/auth/logout`, `GET /api/me` | yes | |
| `GET/POST /api/watchlist`, `DELETE /api/watchlist/:symbol` | yes | |
| `GET /api/portfolio` | yes | `totalValue`, balances (amount/locked/available), open positions |
| `POST /api/orders` `{symbol,side,type,amount,price?,stopPrice?}` | yes | `type`: market / limit / stop |
| `GET /api/orders?status=open\|filled\|cancelled`, `DELETE /api/orders/:id` | yes | |
| `GET /api/trades` | yes | |
| `GET /api/positions?status=open\|closed\|liquidated\|all` | yes | |
| `POST /api/positions` `{symbol,side:long\|short,size,leverage?}` | yes | max leverage 20, default 5 |
| `POST /api/positions/:id/close` | yes | |
| `GET /api/deposit-info`, `POST /api/deposits`, `GET /api/deposits` | | deposit routes need auth |
| `POST /api/admin/deposits/:id/confirm\|reject` | `X-Admin-Key` | disabled unless `ADMIN_KEY` is set |

Errors look like `{ "error": "message", "code": "INSUFFICIENT_FUNDS" }` with a proper HTTP status.

## WebSocket (`ws://localhost:3000/ws`)

Client → server: `{"type":"subscribe","symbol":"ETH"}` and `{"type":"auth","token":"..."}`.
Server → client, every tick (~1.8 s): `tick` (all markets), `book` and `candle` (for the subscribed symbol), `portfolio` (when authed).
Pushed immediately: `order` and `position` events (fills, cancellations, liquidations).

Frontend example (replaces the fake generators in `index.html`):

```js
const API = 'http://localhost:3000';
const candles = (await (await fetch(`${API}/api/markets/BTC/candles?tf=1D`)).json()).candles;

const ws = new WebSocket('ws://localhost:3000/ws');
ws.onopen = () => { ws.send(JSON.stringify({ type: 'subscribe', symbol: 'BTC' })); ws.send(JSON.stringify({ type: 'auth', token })); };
ws.onmessage = (e) => { const m = JSON.parse(e.data); if (m.type === 'tick') renderWatchlist(m.markets); /* book, candle, portfolio, order... */ };

await fetch(`${API}/api/orders`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
  body: JSON.stringify({ symbol: 'BTC', side: 'buy', type: 'market', amount: 0.1 }) });
```

## Database (SQLite, `data/vertex.db`)

`users`, `sessions` (hashed tokens), `markets`, `candles` (per symbol and timeframe), `balances` (amount + locked), `watchlist`, `orders`, `trades`, `positions`, `deposits`.
Every balance change happens inside a transaction. Resting buy orders lock USD, resting sell orders lock the asset, and cancelling or filling releases the lock.

## Rules implemented

- Fee 0.05% on every fill. Market orders fill at the best ask (buy) or bid (sell).
- Limit orders that already cross the book fill immediately; otherwise they rest and fill when the price reaches them. Stop orders trigger when the price crosses the stop.
- Positions: margin = value / leverage; liquidation price = entry × (1 ∓ 0.9 / leverage), checked every tick. `roe` is PnL relative to margin.
- Passwords use scrypt; sessions last 7 days; login/register are rate limited.
- Amounts are stored as floating point and rounded to 8 decimals. That is fine for a simulator; use integer minor units before handling real money.

## Config

`PORT`, `DB_PATH`, `TICK_MS`, `CORS_ORIGIN` (set to your frontend URL in production), `STARTING_USD`, `DEPOSIT_*`, `ADMIN_KEY`.
