'use strict';
const path = require('node:path');

const num = (v, d) => (v !== undefined && v !== '' && Number.isFinite(Number(v)) ? Number(v) : d);

module.exports = {
  PORT: num(process.env.PORT, 3000),
  DB_PATH: process.env.DB_PATH || path.join(__dirname, '..', 'data', 'vertex.db'),
  TICK_MS: num(process.env.TICK_MS, 1800),
  CORS_ORIGIN: process.env.CORS_ORIGIN || '*',
  SESSION_DAYS: 7,

  // Trading
  FEE_RATE: 0.0005,          // 0.05% taker fee, matches the UI
  HALF_SPREAD: 0.00003,      // bid/ask are mid -/+ this fraction
  MAX_LEVERAGE: 20,
  STARTING_USD: num(process.env.STARTING_USD, 100000), // paper-trading credit for new accounts (set 0 for deposit-only)

  // Deposits (manual bank-transfer flow, confirmed by an admin)
  DEPOSIT_BANK_ACCOUNT: process.env.DEPOSIT_BANK_ACCOUNT || '',
  DEPOSIT_BANK_NAME: process.env.DEPOSIT_BANK_NAME || '',
  DEPOSIT_ACCOUNT_NAME: process.env.DEPOSIT_ACCOUNT_NAME || '',
  DEPOSIT_CURRENCY: process.env.DEPOSIT_CURRENCY || 'USD',
  DEPOSIT_TO_USD_RATE: num(process.env.DEPOSIT_TO_USD_RATE, 1), // e.g. 0.0077 if you collect KES
  ADMIN_KEY: process.env.ADMIN_KEY || '', // admin endpoints are disabled when empty

  // Candle timeframes (same as the frontend buttons)
  TIMEFRAMES: {
    '1D': { count: 96, stepMs: 15 * 60e3 },
    '1W': { count: 168, stepMs: 60 * 60e3 },
    '1M': { count: 120, stepMs: 6 * 60 * 60e3 },
    '3M': { count: 180, stepMs: 12 * 60 * 60e3 },
    '1Y': { count: 365, stepMs: 24 * 60 * 60e3 },
  },
};
