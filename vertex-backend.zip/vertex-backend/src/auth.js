'use strict';
const crypto = require('node:crypto');
const { db } = require('./db');
const { SESSION_DAYS } = require('./config');
const { ApiError } = require('./errors');

const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');

function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(password, salt, 64);
  return `scrypt$${salt.toString('hex')}$${hash.toString('hex')}`;
}
function verifyPassword(password, stored) {
  const [scheme, saltHex, hashHex] = String(stored).split('$');
  if (scheme !== 'scrypt' || !saltHex || !hashHex) return false;
  const expected = Buffer.from(hashHex, 'hex');
  const actual = crypto.scryptSync(password, Buffer.from(saltHex, 'hex'), expected.length);
  return crypto.timingSafeEqual(actual, expected);
}
const DUMMY_HASH = hashPassword('dummy-password-for-timing');

const S = {
  insSession: db.prepare('INSERT INTO sessions (token_hash,user_id,created_at,expires_at) VALUES (?,?,?,?)'),
  byToken: db.prepare(`SELECT u.id, u.email, u.name FROM sessions s JOIN users u ON u.id = s.user_id
                       WHERE s.token_hash = ? AND s.expires_at > ?`),
  delSession: db.prepare('DELETE FROM sessions WHERE token_hash = ?'),
  purge: db.prepare('DELETE FROM sessions WHERE expires_at <= ?'),
  userByEmail: db.prepare('SELECT * FROM users WHERE email = ?'),
};

function createSession(userId) {
  const token = crypto.randomBytes(32).toString('hex');
  const now = Date.now();
  S.insSession.run(sha256(token), userId, now, now + SESSION_DAYS * 86400e3);
  return token;
}
const userFromToken = (token) => (token ? S.byToken.get(sha256(String(token)), Date.now()) || null : null);
const destroySession = (token) => S.delSession.run(sha256(String(token)));
const purgeExpired = () => S.purge.run(Date.now());

function login(email, password) {
  const row = S.userByEmail.get(String(email || '').trim());
  const ok = verifyPassword(String(password || ''), row ? row.password_hash : DUMMY_HASH);
  if (!row || !ok) throw new ApiError(401, 'Invalid email or password', 'BAD_CREDENTIALS');
  return row;
}

function bearer(req) {
  const h = req.headers.authorization || '';
  return h.startsWith('Bearer ') ? h.slice(7).trim() : null;
}

module.exports = { hashPassword, verifyPassword, createSession, userFromToken, destroySession, purgeExpired, login, bearer };
