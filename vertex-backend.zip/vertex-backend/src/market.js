'use strict';
const EventEmitter = require('node:events');
const { db, tx } = require('./db');
const { TIMEFRAMES, TICK_MS, HALF_SPREAD } = require('./config');

const events = new EventEmitter();
const markets = new Map(); // symbol -> in-memory market state
const live = new Map();    // `${symbol}|${tf}` -> current (open) candle
let timer = null;

const q = {
  all: db.prepare('SELECT * FROM markets ORDER BY rowid'),
  setPrice: db.prepare('UPDATE markets SET price = ?, updated_at = ? WHERE symbol = ?'),
  lastCandle: db.prepare('SELECT t,o,h,l,c,v FROM candles WHERE symbol = ? AND tf = ? ORDER BY t DESC LIMIT 1'),
  recent: db.prepare('SELECT t,o,h,l,c,v FROM candles WHERE symbol = ? AND tf = ? ORDER BY t DESC LIMIT ?'),
  upsert: db.prepare(`INSERT INTO candles (symbol,tf,t,o,h,l,c,v) VALUES (?,?,?,?,?,?,?,?)
    ON CONFLICT(symbol,tf,t) DO UPDATE SET h = excluded.h, l = excluded.l, c = excluded.c, v = excluded.v`),
};

const bucket = (tf, ts) => Math.floor(ts / TIMEFRAMES[tf].stepMs) * TIMEFRAMES[tf].stepMs;

function init() {
  markets.clear();
  live.clear();
  const now = Date.now();
  for (const r of q.all.all()) {
    const m = {
      symbol: r.symbol, pair: r.pair, name: r.name, icon: r.icon, color: r.color,
      decimals: r.decimals, price: r.price, anchor: r.anchor,
      dailyVolumeUsd: r.daily_volume_usd, stats: null,
    };
    markets.set(m.symbol, m);
    for (const tf of Object.keys(TIMEFRAMES)) {
      const last = q.lastCandle.get(m.symbol, tf);
      const t = bucket(tf, now);
      live.set(`${m.symbol}|${tf}`, last && last.t === t
        ? { ...last }
        : { t, o: m.price, h: m.price, l: m.price, c: m.price, v: 0 });
    }
    refreshStats(m);
  }
}

function refreshStats(m) {
  const day = q.recent.all(m.symbol, '1D', 96);
  const open24h = day.length ? day[day.length - 1].o : m.price;
  let high = m.price, low = m.price, vol = 0;
  for (const c of day) { if (c.h > high) high = c.h; if (c.l < low) low = c.l; vol += c.v; }
  const spark = q.recent.all(m.symbol, '1W', 24).reverse().map((c) => c.c);
  m.stats = {
    open24h,
    change24h: ((m.price - open24h) / open24h) * 100,
    high24h: high,
    low24h: low,
    volume24hUsd: vol * m.price,
    spark,
  };
}

function tick() {
  const now = Date.now();
  tx(() => {
    for (const m of markets.values()) {
      // random walk with a gentle pull back to the anchor price so prices stay sane over days
      const ret = (Math.random() * 2 - 1) * 0.0009 + ((m.anchor - m.price) / m.anchor) * 0.00005;
      m.price = Math.max(m.price * (1 + ret), 1e-6);
      const volUsd = (m.dailyVolumeUsd / (86400000 / TICK_MS)) * (0.4 + Math.random() * 1.2);
      for (const tf of Object.keys(TIMEFRAMES)) {
        const key = `${m.symbol}|${tf}`;
        const t = bucket(tf, now);
        let c = live.get(key);
        if (c.t !== t) {
          c = { t, o: c.c, h: Math.max(c.c, m.price), l: Math.min(c.c, m.price), c: m.price, v: 0 };
          live.set(key, c);
        } else {
          c.h = Math.max(c.h, m.price);
          c.l = Math.min(c.l, m.price);
          c.c = m.price;
        }
        c.v += volUsd / m.price;
        q.upsert.run(m.symbol, tf, c.t, c.o, c.h, c.l, c.c, c.v);
      }
      q.setPrice.run(m.price, now, m.symbol);
    }
  });
  for (const m of markets.values()) refreshStats(m);
  events.emit('tick', { ts: now });
}

function start() {
  if (timer) return;
  timer = setInterval(() => {
    try { tick(); } catch (err) { console.error('[market] tick failed:', err); }
  }, TICK_MS);
  timer.unref?.();
}
function stop() { clearInterval(timer); timer = null; }

const has = (symbol) => markets.has(symbol);
const get = (symbol) => markets.get(symbol);

function touch(symbol) {
  const mid = markets.get(symbol).price;
  return { mid, bid: mid * (1 - HALF_SPREAD), ask: mid * (1 + HALF_SPREAD) };
}

function snapshot(m) {
  const t = touch(m.symbol);
  return {
    symbol: m.symbol, pair: m.pair, name: m.name, icon: m.icon, color: m.color, decimals: m.decimals,
    price: m.price, bid: t.bid, ask: t.ask, ...m.stats,
  };
}
const snapshots = () => [...markets.values()].map(snapshot);

function currentCandles(symbol) {
  const out = {};
  for (const tf of Object.keys(TIMEFRAMES)) out[tf] = { ...live.get(`${symbol}|${tf}`) };
  return out;
}

function candles(symbol, tf, limit) {
  const n = Math.min(Math.max(1, limit || TIMEFRAMES[tf].count), 1000);
  return q.recent.all(symbol, tf, n).reverse().map((c) => ({ ...c }));
}

// ---- synthetic order book (deterministic per symbol + tick, so every client sees the same book) ----
function mulberry32(a) {
  return () => {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function hashStr(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}

function book(symbol, levels = 11) {
  const m = markets.get(symbol);
  const t = touch(symbol);
  const rnd = mulberry32(hashStr(symbol) ^ Math.floor(Date.now() / TICK_MS));
  const scale = 67842 / m.price; // keep per-level notional comparable across assets
  const side = (start, dir) => {
    let p = start, total = 0;
    const rows = [];
    for (let i = 0; i < levels; i++) {
      const size = (0.02 + rnd() * 2.38) * scale;
      total += size;
      rows.push({ price: p, size, total });
      p += dir * m.price * 0.00012 * (0.6 + rnd());
    }
    return rows;
  };
  const asks = side(t.ask, +1); // best (lowest) first
  const bids = side(t.bid, -1); // best (highest) first
  return {
    symbol, ts: Date.now(), asks, bids,
    spread: t.ask - t.bid, spreadPct: ((t.ask - t.bid) / t.mid) * 100,
  };
}

module.exports = { events, init, start, stop, tick, has, get, touch, snapshot, snapshots, currentCandles, candles, book, list: () => [...markets.values()] };
