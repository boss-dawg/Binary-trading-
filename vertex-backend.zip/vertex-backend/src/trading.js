'use strict';
const EventEmitter = require('node:events');
const { db, tx } = require('./db');
const market = require('./market');
const { FEE_RATE, MAX_LEVERAGE } = require('./config');
const { ApiError, num, positive } = require('./errors');

const events = new EventEmitter(); // 'order' (userId, orderDto) | 'position' (userId, positionDto)
const EPS = 1e-9;
const r8 = (x) => Math.round(x * 1e8) / 1e8;

const S = {
  bal: db.prepare('SELECT amount, locked FROM balances WHERE user_id = ? AND asset = ?'),
  setBal: db.prepare(`INSERT INTO balances (user_id,asset,amount,locked) VALUES (?,?,?,?)
    ON CONFLICT(user_id,asset) DO UPDATE SET amount = excluded.amount, locked = excluded.locked`),
  balances: db.prepare('SELECT asset, amount, locked FROM balances WHERE user_id = ? AND (amount > 0 OR locked > 0) ORDER BY asset'),

  insOrder: db.prepare(`INSERT INTO orders (user_id,symbol,side,type,amount,price,stop_price,status,locked_asset,locked_amount,created_at,updated_at)
    VALUES (?,?,?,?,?,?,?,'open',?,?,?,?)`),
  order: db.prepare('SELECT * FROM orders WHERE id = ?'),
  fillOrder: db.prepare(`UPDATE orders SET status='filled', filled_amount=?, avg_price=?, fee=?, locked_amount=0, updated_at=? WHERE id=?`),
  cancelOrder: db.prepare(`UPDATE orders SET status='cancelled', cancel_reason=?, locked_amount=0, updated_at=? WHERE id=?`),
  openResting: db.prepare(`SELECT id FROM orders WHERE status='open' AND symbol = ? AND type IN ('limit','stop')`),
  insTrade: db.prepare('INSERT INTO trades (user_id,order_id,symbol,side,amount,price,fee,created_at) VALUES (?,?,?,?,?,?,?,?)'),

  insPos: db.prepare(`INSERT INTO positions (user_id,symbol,side,size,entry_price,leverage,margin,liq_price,open_fee,status,opened_at)
    VALUES (?,?,?,?,?,?,?,?,?,'open',?)`),
  pos: db.prepare('SELECT * FROM positions WHERE id = ?'),
  closePos: db.prepare(`UPDATE positions SET status = ?, exit_price = ?, realized_pnl = ?, closed_at = ? WHERE id = ?`),
  openPosBySymbol: db.prepare(`SELECT id FROM positions WHERE status = 'open' AND symbol = ?`),
};

// ---------------------------------------------------------------- balances
// dAmount changes the total; dLocked changes the reserved part. Available = amount - locked.
function adjust(userId, asset, dAmount, dLocked = 0) {
  const cur = S.bal.get(userId, asset) || { amount: 0, locked: 0 };
  const amount = r8(cur.amount + dAmount);
  const locked = r8(cur.locked + dLocked);
  if (amount < -EPS || locked < -EPS || amount - locked < -EPS) {
    throw new ApiError(400, `Insufficient ${asset} balance`, 'INSUFFICIENT_FUNDS');
  }
  S.setBal.run(userId, asset, Math.max(0, amount), Math.max(0, locked));
}

// ---------------------------------------------------------------- DTOs
const orderDto = (r) => ({
  id: r.id, symbol: r.symbol, side: r.side, type: r.type, amount: r.amount,
  price: r.price, stopPrice: r.stop_price, filledAmount: r.filled_amount, avgPrice: r.avg_price,
  fee: r.fee, status: r.status, cancelReason: r.cancel_reason, createdAt: r.created_at, updatedAt: r.updated_at,
});
const tradeDto = (r) => ({
  id: r.id, orderId: r.order_id, symbol: r.symbol, side: r.side, amount: r.amount,
  price: r.price, fee: r.fee, value: r.amount * r.price, createdAt: r.created_at,
});
function positionDto(r) {
  const m = market.get(r.symbol);
  const open = r.status === 'open';
  const mark = open ? m.price : r.exit_price;
  const pnl = open
    ? (r.side === 'long' ? mark - r.entry_price : r.entry_price - mark) * r.size
    : r.realized_pnl;
  return {
    id: r.id, symbol: r.symbol, pair: m.pair, color: m.color, side: r.side, size: r.size,
    entryPrice: r.entry_price, markPrice: mark, liqPrice: r.liq_price, leverage: r.leverage,
    margin: r.margin, pnl, roe: (pnl / r.margin) * 100, status: r.status,
    exitPrice: r.exit_price, openedAt: r.opened_at, closedAt: r.closed_at,
  };
}

// ---------------------------------------------------------------- orders
function validateOrder(input) {
  const i = input || {};
  const symbol = String(i.symbol || '').toUpperCase();
  if (!market.has(symbol)) throw new ApiError(400, 'Unknown market', 'VALIDATION');
  if (!['buy', 'sell'].includes(i.side)) throw new ApiError(400, "side must be 'buy' or 'sell'", 'VALIDATION');
  const type = i.type || 'market';
  if (!['market', 'limit', 'stop'].includes(type)) throw new ApiError(400, "type must be 'market', 'limit' or 'stop'", 'VALIDATION');
  const out = { symbol, side: i.side, type, amount: positive(i.amount, 'amount', 1e9), price: null, stopPrice: null };
  if (type === 'limit') out.price = positive(i.price, 'price');
  if (type === 'stop') out.stopPrice = positive(i.stopPrice, 'stopPrice');
  return out;
}

// Settle a fill at execPx. Throws ApiError(INSUFFICIENT_FUNDS) if the account can't cover it.
function fillOrder(o, execPx) {
  const notional = r8(o.amount * execPx);
  const fee = r8(notional * FEE_RATE);
  if (o.locked_amount > 0) adjust(o.user_id, o.locked_asset, 0, -o.locked_amount);
  if (o.side === 'buy') {
    adjust(o.user_id, 'USD', -(notional + fee));
    adjust(o.user_id, o.symbol, o.amount);
  } else {
    adjust(o.user_id, o.symbol, -o.amount);
    adjust(o.user_id, 'USD', notional - fee);
  }
  const now = Date.now();
  S.insTrade.run(o.user_id, o.id, o.symbol, o.side, o.amount, execPx, fee, now);
  S.fillOrder.run(o.amount, execPx, fee, now, o.id);
}

function placeOrder(userId, input) {
  const v = validateOrder(input);
  const t = market.touch(v.symbol);
  if (v.amount * t.mid < 1) throw new ApiError(400, 'Order value must be at least $1', 'VALIDATION');

  const order = tx(() => {
    let immediate = null;
    if (v.type === 'market') immediate = v.side === 'buy' ? t.ask : t.bid;
    else if (v.type === 'limit') {
      if (v.side === 'buy' && v.price >= t.ask) immediate = t.ask;
      if (v.side === 'sell' && v.price <= t.bid) immediate = t.bid;
    } else {
      if (v.side === 'buy' && v.stopPrice <= t.mid) throw new ApiError(400, 'Buy stop price must be above the current price', 'INVALID_STOP');
      if (v.side === 'sell' && v.stopPrice >= t.mid) throw new ApiError(400, 'Sell stop price must be below the current price', 'INVALID_STOP');
    }

    let lockAsset = null, lockAmount = 0;
    if (!immediate) {
      if (v.side === 'buy') {
        lockAsset = 'USD';
        lockAmount = r8(v.amount * (v.type === 'limit' ? v.price : v.stopPrice) * (1 + FEE_RATE));
      } else {
        lockAsset = v.symbol;
        lockAmount = v.amount;
      }
      adjust(userId, lockAsset, 0, lockAmount);
    }
    const now = Date.now();
    const id = S.insOrder.run(userId, v.symbol, v.side, v.type, v.amount, v.price, v.stopPrice, lockAsset, lockAmount, now, now).lastInsertRowid;
    if (immediate) fillOrder(S.order.get(id), immediate);
    return S.order.get(id);
  });
  const dto = orderDto(order);
  events.emit('order', userId, dto);
  return dto;
}

function cancelInternal(id, reason) {
  const o = S.order.get(id);
  if (!o || o.status !== 'open') return null;
  if (o.locked_amount > 0) adjust(o.user_id, o.locked_asset, 0, -o.locked_amount);
  S.cancelOrder.run(reason, Date.now(), id);
  return S.order.get(id);
}

function cancelOrder(userId, id) {
  const row = tx(() => {
    const o = S.order.get(id);
    if (!o || o.user_id !== userId) throw new ApiError(404, 'Order not found', 'NOT_FOUND');
    if (o.status !== 'open') throw new ApiError(409, `Order is already ${o.status}`, 'NOT_OPEN');
    return cancelInternal(id, 'cancelled by user');
  });
  const dto = orderDto(row);
  events.emit('order', userId, dto);
  return dto;
}

// ---------------------------------------------------------------- positions
function openPosition(userId, input) {
  const i = input || {};
  const symbol = String(i.symbol || '').toUpperCase();
  if (!market.has(symbol)) throw new ApiError(400, 'Unknown market', 'VALIDATION');
  if (!['long', 'short'].includes(i.side)) throw new ApiError(400, "side must be 'long' or 'short'", 'VALIDATION');
  const size = positive(i.size, 'size', 1e9);
  const leverage = i.leverage == null ? 5 : num(i.leverage, 'leverage');
  if (leverage < 1 || leverage > MAX_LEVERAGE) throw new ApiError(400, `leverage must be between 1 and ${MAX_LEVERAGE}`, 'VALIDATION');

  const t = market.touch(symbol);
  const entry = i.side === 'long' ? t.ask : t.bid;
  const notional = size * entry;
  if (notional < 1) throw new ApiError(400, 'Position value must be at least $1', 'VALIDATION');
  const margin = r8(notional / leverage);
  const fee = r8(notional * FEE_RATE);
  const liq = i.side === 'long' ? entry * (1 - 0.9 / leverage) : entry * (1 + 0.9 / leverage);

  const row = tx(() => {
    adjust(userId, 'USD', -(margin + fee));
    const id = S.insPos.run(userId, symbol, i.side, size, entry, leverage, margin, liq, fee, Date.now()).lastInsertRowid;
    return S.pos.get(id);
  });
  const dto = positionDto(row);
  events.emit('position', userId, dto);
  return dto;
}

function closePosition(userId, id) {
  const row = tx(() => {
    const p = S.pos.get(id);
    if (!p || p.user_id !== userId) throw new ApiError(404, 'Position not found', 'NOT_FOUND');
    if (p.status !== 'open') throw new ApiError(409, `Position is already ${p.status}`, 'NOT_OPEN');
    const t = market.touch(p.symbol);
    const exit = p.side === 'long' ? t.bid : t.ask;
    const pnl = (p.side === 'long' ? exit - p.entry_price : p.entry_price - exit) * p.size;
    const closeFee = r8(exit * p.size * FEE_RATE);
    adjust(userId, 'USD', Math.max(0, r8(p.margin + pnl - closeFee)));
    S.closePos.run('closed', exit, r8(pnl - p.open_fee - closeFee), Date.now(), id);
    return S.pos.get(id);
  });
  const dto = positionDto(row);
  events.emit('position', userId, dto);
  return dto;
}

// ---------------------------------------------------------------- per-tick engine
function processTick(symbol) {
  const t = market.touch(symbol);

  for (const { id } of S.openResting.all(symbol)) {
    const probe = S.order.get(id);
    let px = null;
    if (probe.type === 'limit') {
      if (probe.side === 'buy' && t.ask <= probe.price) px = t.ask;
      if (probe.side === 'sell' && t.bid >= probe.price) px = t.bid;
    } else {
      if (probe.side === 'buy' && t.mid >= probe.stop_price) px = t.ask;
      if (probe.side === 'sell' && t.mid <= probe.stop_price) px = t.bid;
    }
    if (px == null) continue;
    let result = null;
    try {
      result = tx(() => {
        const o = S.order.get(id);
        if (o.status !== 'open') return null;
        fillOrder(o, px);
        return S.order.get(id);
      });
    } catch (err) {
      if (!(err instanceof ApiError)) throw err;
      result = tx(() => cancelInternal(id, err.message));
    }
    if (result) events.emit('order', probe.user_id, orderDto(result));
  }

  for (const { id } of S.openPosBySymbol.all(symbol)) {
    const p = S.pos.get(id);
    const hit = p.side === 'long' ? t.mid <= p.liq_price : t.mid >= p.liq_price;
    if (!hit) continue;
    const row = tx(() => {
      S.closePos.run('liquidated', p.liq_price, r8(-(p.margin + p.open_fee)), Date.now(), id);
      return S.pos.get(id);
    });
    events.emit('position', p.user_id, positionDto(row));
  }
}

// ---------------------------------------------------------------- reads
const clampLimit = (n) => Math.min(Math.max(parseInt(n, 10) || 50, 1), 200);

function listOrders(userId, { status, limit, offset } = {}) {
  const where = ['user_id = ?'];
  const args = [userId];
  if (status && status !== 'all') {
    if (!['open', 'filled', 'cancelled'].includes(status)) throw new ApiError(400, 'invalid status', 'VALIDATION');
    where.push('status = ?'); args.push(status);
  }
  return db.prepare(`SELECT * FROM orders WHERE ${where.join(' AND ')} ORDER BY id DESC LIMIT ? OFFSET ?`)
    .all(...args, clampLimit(limit), Math.max(parseInt(offset, 10) || 0, 0)).map(orderDto);
}
function listTrades(userId, { limit, offset } = {}) {
  return db.prepare('SELECT * FROM trades WHERE user_id = ? ORDER BY id DESC LIMIT ? OFFSET ?')
    .all(userId, clampLimit(limit), Math.max(parseInt(offset, 10) || 0, 0)).map(tradeDto);
}
function listPositions(userId, { status, limit } = {}) {
  const st = status || 'open';
  if (!['open', 'closed', 'liquidated', 'all'].includes(st)) throw new ApiError(400, 'invalid status', 'VALIDATION');
  const rows = st === 'all'
    ? db.prepare('SELECT * FROM positions WHERE user_id = ? ORDER BY id DESC LIMIT ?').all(userId, clampLimit(limit))
    : db.prepare('SELECT * FROM positions WHERE user_id = ? AND status = ? ORDER BY id DESC LIMIT ?').all(userId, st, clampLimit(limit));
  return rows.map(positionDto);
}

function portfolio(userId) {
  const balances = S.balances.all(userId).map((b) => {
    const price = b.asset === 'USD' ? 1 : market.get(b.asset)?.price ?? 0;
    return { asset: b.asset, amount: b.amount, locked: b.locked, available: r8(b.amount - b.locked), price, valueUsd: b.amount * price };
  });
  const positions = listPositions(userId, { status: 'open' });
  const holdings = balances.reduce((s, b) => s + b.valueUsd, 0);
  const inPositions = positions.reduce((s, p) => s + p.margin + p.pnl, 0);
  const unrealizedPnl = positions.reduce((s, p) => s + p.pnl, 0);
  const openOrders = db.prepare(`SELECT COUNT(*) n FROM orders WHERE user_id = ? AND status = 'open'`).get(userId).n;
  return { totalValue: holdings + inPositions, unrealizedPnl, balances, positions, openOrders };
}

module.exports = {
  events, adjust, placeOrder, cancelOrder, openPosition, closePosition, processTick,
  listOrders, listTrades, listPositions, portfolio, orderDto, positionDto, r8,
};
