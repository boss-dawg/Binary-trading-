'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const { DB_PATH } = require('./config');

if (DB_PATH !== ':memory:') fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
  name          TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  created_at    INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);

CREATE TABLE IF NOT EXISTS markets (
  symbol           TEXT PRIMARY KEY,
  pair             TEXT NOT NULL,
  name             TEXT NOT NULL,
  icon             TEXT NOT NULL,
  color            TEXT NOT NULL,
  decimals         INTEGER NOT NULL DEFAULT 2,
  price            REAL NOT NULL,
  anchor           REAL NOT NULL,
  daily_volume_usd REAL NOT NULL,
  updated_at       INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS candles (
  symbol TEXT NOT NULL,
  tf     TEXT NOT NULL,
  t      INTEGER NOT NULL,
  o REAL NOT NULL, h REAL NOT NULL, l REAL NOT NULL, c REAL NOT NULL, v REAL NOT NULL,
  PRIMARY KEY (symbol, tf, t)
) WITHOUT ROWID;

CREATE TABLE IF NOT EXISTS balances (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  asset   TEXT NOT NULL,
  amount  REAL NOT NULL DEFAULT 0 CHECK (amount >= 0),
  locked  REAL NOT NULL DEFAULT 0 CHECK (locked >= 0),
  PRIMARY KEY (user_id, asset)
);

CREATE TABLE IF NOT EXISTS watchlist (
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  symbol     TEXT NOT NULL REFERENCES markets(symbol),
  created_at INTEGER NOT NULL,
  PRIMARY KEY (user_id, symbol)
);

CREATE TABLE IF NOT EXISTS orders (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  symbol        TEXT NOT NULL REFERENCES markets(symbol),
  side          TEXT NOT NULL CHECK (side IN ('buy','sell')),
  type          TEXT NOT NULL CHECK (type IN ('market','limit','stop')),
  amount        REAL NOT NULL CHECK (amount > 0),
  price         REAL,
  stop_price    REAL,
  filled_amount REAL NOT NULL DEFAULT 0,
  avg_price     REAL,
  fee           REAL NOT NULL DEFAULT 0,
  status        TEXT NOT NULL CHECK (status IN ('open','filled','cancelled')),
  cancel_reason TEXT,
  locked_asset  TEXT,
  locked_amount REAL NOT NULL DEFAULT 0,
  created_at    INTEGER NOT NULL,
  updated_at    INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_open ON orders(status, symbol);

CREATE TABLE IF NOT EXISTS trades (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  order_id   INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  symbol     TEXT NOT NULL,
  side       TEXT NOT NULL,
  amount     REAL NOT NULL,
  price      REAL NOT NULL,
  fee        REAL NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_trades_user ON trades(user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS positions (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  symbol      TEXT NOT NULL REFERENCES markets(symbol),
  side        TEXT NOT NULL CHECK (side IN ('long','short')),
  size        REAL NOT NULL CHECK (size > 0),
  entry_price REAL NOT NULL,
  leverage    REAL NOT NULL,
  margin      REAL NOT NULL,
  liq_price   REAL NOT NULL,
  open_fee    REAL NOT NULL DEFAULT 0,
  status      TEXT NOT NULL CHECK (status IN ('open','closed','liquidated')),
  exit_price  REAL,
  realized_pnl REAL,
  opened_at   INTEGER NOT NULL,
  closed_at   INTEGER
);
CREATE INDEX IF NOT EXISTS idx_positions_user ON positions(user_id, status);
CREATE INDEX IF NOT EXISTS idx_positions_open ON positions(status, symbol);

CREATE TABLE IF NOT EXISTS deposits (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  amount       REAL NOT NULL CHECK (amount > 0),
  currency     TEXT NOT NULL,
  reference    TEXT NOT NULL UNIQUE,
  bank_account TEXT NOT NULL,
  status       TEXT NOT NULL CHECK (status IN ('pending','confirmed','rejected')),
  created_at   INTEGER NOT NULL,
  resolved_at  INTEGER
);
CREATE INDEX IF NOT EXISTS idx_deposits_user ON deposits(user_id, created_at DESC);
`);

// Run fn inside one write transaction. Nested calls join the outer one.
let depth = 0;
function tx(fn) {
  if (depth > 0) return fn();
  db.exec('BEGIN IMMEDIATE');
  depth++;
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  } finally {
    depth--;
  }
}

module.exports = { db, tx };
