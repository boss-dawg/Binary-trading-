'use strict';
const { db, tx } = require('./db');
const { TIMEFRAMES, FEE_RATE } = require('./config');
const { hashPassword } = require('./auth');

const MARKETS = [
  { symbol: 'BTC',   name: 'Bitcoin',   icon: '₿', color: '#F7931A', price: 67842.30, vol: 2.14e9, decimals: 2 },
  { symbol: 'ETH',   name: 'Ethereum',  icon: 'Ξ', color: '#627EEA', price: 3512.88,  vol: 1.02e9, decimals: 2 },
  { symbol: 'SOL',   name: 'Solana',    icon: '◎', color: '#14F195', price: 172.14,   vol: 612e6,  decimals: 2 },
  { symbol: 'AVAX',  name: 'Avalanche', icon: '▲', color: '#E84142', price: 38.42,    vol: 188e6,  decimals: 2 },
  { symbol: 'LINK',  name: 'Chainlink', icon: '⬡', color: '#2A5ADA', price: 16.905,   vol: 210e6,  decimals: 3 },
  { symbol: 'MATIC', name: 'Polygon',   icon: '⬟', color: '#8247E5', price: 0.6412,   vol: 96e6,   decimals: 4 },
  { symbol: 'ADA',   name: 'Cardano',   icon: '₳', color: '#3CC8C8', price: 0.4488,   vol: 78e6,   decimals: 4 },
  { symbol: 'DOT',   name: 'Polkadot',  icon: '●', color: '#E6007A', price: 6.712,    vol: 54e6,   decimals: 3 },
];

const DEMO = { email: 'demo@vertex.app', password: 'demo1234', name: 'Demo Trader' };

// Walk backwards from the current price so history joins up with the live candle.
function backfill(insert, symbol, tf, endPrice, dailyVolUsd) {
  const { count, stepMs } = TIMEFRAMES[tf];
  const lastT = Math.floor(Date.now() / stepMs) * stepMs;
  const sigma = 0.0025 * Math.sqrt(stepMs / (15 * 60e3));
  let close = endPrice;
  for (let i = 0; i < count; i++) {
    const ret = (Math.random() * 2 - 1) * sigma * 1.7;
    const open = close / (1 + ret);
    const hi = Math.max(open, close) * (1 + Math.random() * sigma * 0.5);
    const lo = Math.min(open, close) * (1 - Math.random() * sigma * 0.5);
    const vol = (dailyVolUsd / (86400000 / stepMs) / ((open + close) / 2)) * (0.4 + Math.random() * 1.2);
    insert.run(symbol, tf, lastT - i * stepMs, open, hi, lo, close, vol);
    close = open;
  }
}

function seedIfEmpty() {
  if (db.prepare('SELECT COUNT(*) n FROM markets').get().n > 0) return false;

  tx(() => {
    const now = Date.now();
    const insMarket = db.prepare(`INSERT INTO markets (symbol,pair,name,icon,color,decimals,price,anchor,daily_volume_usd,updated_at)
                                  VALUES (?,?,?,?,?,?,?,?,?,?)`);
    const insCandle = db.prepare('INSERT OR REPLACE INTO candles (symbol,tf,t,o,h,l,c,v) VALUES (?,?,?,?,?,?,?,?)');
    for (const m of MARKETS) {
      insMarket.run(m.symbol, `${m.symbol}/USD`, m.name, m.icon, m.color, m.decimals, m.price, m.price, m.vol, now);
      for (const tf of Object.keys(TIMEFRAMES)) backfill(insCandle, m.symbol, tf, m.price, m.vol);
    }

    // demo account with a few holdings, open positions and a resting limit order
    const uid = db.prepare('INSERT INTO users (email,name,password_hash,created_at) VALUES (?,?,?,?)')
      .run(DEMO.email, DEMO.name, hashPassword(DEMO.password), now).lastInsertRowid;

    const limit = { symbol: 'BTC', amount: 0.25, price: 66500 };
    const lock = Math.round(limit.amount * limit.price * (1 + FEE_RATE) * 1e8) / 1e8;
    const bal = db.prepare('INSERT INTO balances (user_id,asset,amount,locked) VALUES (?,?,?,?)');
    bal.run(uid, 'USD', 25000, lock);
    bal.run(uid, 'BTC', 2.4410, 0);
    bal.run(uid, 'ETH', 14.802, 0);
    bal.run(uid, 'SOL', 220.5, 0);

    db.prepare(`INSERT INTO orders (user_id,symbol,side,type,amount,price,status,locked_asset,locked_amount,created_at,updated_at)
                VALUES (?,?,?,?,?,?,'open','USD',?,?,?)`).run(uid, limit.symbol, 'buy', 'limit', limit.amount, limit.price, lock, now, now);

    const wl = db.prepare('INSERT INTO watchlist (user_id,symbol,created_at) VALUES (?,?,?)');
    for (const m of MARKETS) wl.run(uid, m.symbol, now);

    const insPos = db.prepare(`INSERT INTO positions (user_id,symbol,side,size,entry_price,leverage,margin,liq_price,open_fee,status,opened_at)
                               VALUES (?,?,?,?,?,?,?,?,?,'open',?)`);
    for (const p of [
      { symbol: 'BTC', side: 'long',  size: 0.842, entry: 64210.00 },
      { symbol: 'ETH', side: 'long',  size: 6.20,  entry: 3390.50 },
      { symbol: 'SOL', side: 'short', size: 120,   entry: 181.20 },
    ]) {
      const lev = 5, notional = p.size * p.entry;
      const liq = p.side === 'long' ? p.entry * (1 - 0.9 / lev) : p.entry * (1 + 0.9 / lev);
      insPos.run(uid, p.symbol, p.side, p.size, p.entry, lev, notional / lev, liq, notional * FEE_RATE, now - 3 * 86400e3);
    }
  });
  return true;
}

module.exports = { seedIfEmpty, DEMO };
