'use strict';
const http = require('node:http');
const crypto = require('node:crypto');
const cfg = require('./config');
const { db, tx } = require('./db');
const { ApiError } = require('./errors');
const auth = require('./auth');
const market = require('./market');
const trading = require('./trading');
const deposits = require('./deposits');
const ws = require('./ws');
const { seedIfEmpty, DEMO } = require('./seed');

// ------------------------------------------------------------------ bootstrap
if (seedIfEmpty()) {
  console.log(`[seed] database created. Demo login: ${DEMO.email} / ${DEMO.password}`);
}
market.init();
auth.purgeExpired();

// ------------------------------------------------------------------ tiny router
const routes = [];
function route(method, pattern, opts, handler) {
  if (typeof opts === 'function') { handler = opts; opts = {}; }
  const keys = [];
  const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '/?$');
  routes.push({ method, re, keys, handler, ...opts });
}

const hits = new Map();
function rateLimit(max, windowMs) {
  return (req) => {
    const now = Date.now();
    const key = req.socket.remoteAddress;
    const recent = (hits.get(key) || []).filter((t) => now - t < windowMs);
    if (recent.length >= max) throw new ApiError(429, 'Too many attempts, try again later', 'RATE_LIMITED');
    recent.push(now);
    hits.set(key, recent);
  };
}
setInterval(() => hits.clear(), 15 * 60e3).unref();
const authLimit = rateLimit(20, 15 * 60e3);

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', cfg.CORS_ORIGIN);
  res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type, X-Admin-Key');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Max-Age', '600');
}

function sendJson(res, status, body) {
  const data = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(data),
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
  });
  res.end(data);
}

function readBody(req, limit = 100 * 1024) {
  return new Promise((resolve, reject) => {
    if (req.method === 'GET' || req.method === 'OPTIONS') return resolve({});
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(new ApiError(413, 'Request body too large', 'TOO_LARGE')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try {
        const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'));
        resolve(parsed && typeof parsed === 'object' ? parsed : {});
      } catch { reject(new ApiError(400, 'Invalid JSON body', 'BAD_JSON')); }
    });
    req.on('error', reject);
  });
}

async function handle(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
  try {
    const url = new URL(req.url, 'http://localhost');
    let matched = null;
    let params = {};
    let pathExists = false;
    for (const r of routes) {
      const m = r.re.exec(url.pathname);
      if (!m) continue;
      pathExists = true;
      if (r.method !== req.method) continue;
      matched = r;
      r.keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); });
      break;
    }
    if (!matched) throw new ApiError(pathExists ? 405 : 404, pathExists ? 'Method not allowed' : 'Not found', 'NOT_FOUND');

    matched.limit?.(req);
    const ctx = { req, params, query: Object.fromEntries(url.searchParams), body: await readBody(req), user: null };
    if (matched.auth) {
      ctx.user = auth.userFromToken(auth.bearer(req));
      if (!ctx.user) throw new ApiError(401, 'Authentication required', 'UNAUTHORIZED');
    }
    if (matched.admin) {
      const given = Buffer.from(String(req.headers['x-admin-key'] || ''));
      const want = Buffer.from(cfg.ADMIN_KEY);
      if (!cfg.ADMIN_KEY || given.length !== want.length || !crypto.timingSafeEqual(given, want)) {
        throw new ApiError(cfg.ADMIN_KEY ? 403 : 404, cfg.ADMIN_KEY ? 'Forbidden' : 'Not found', 'FORBIDDEN');
      }
    }
    const out = await matched.handler(ctx);
    if (out && out.__status) sendJson(res, out.__status, out.body);
    else sendJson(res, 200, out ?? { ok: true });
  } catch (err) {
    if (err instanceof ApiError) return sendJson(res, err.status, { error: err.message, code: err.code });
    console.error('[http] unexpected error:', err);
    sendJson(res, 500, { error: 'Internal server error', code: 'INTERNAL' });
  }
}
const created = (body) => ({ __status: 201, body });
const needMarket = (symbol) => {
  const s = String(symbol).toUpperCase();
  if (!market.has(s)) throw new ApiError(404, 'Unknown market', 'NOT_FOUND');
  return s;
};

// ------------------------------------------------------------------ routes: system + market data
route('GET', '/api/health', () => ({ ok: true, uptime: process.uptime(), markets: market.list().length, time: Date.now() }));

route('GET', '/api/markets', ({ query }) => {
  let list = market.snapshots();
  if (query.q) {
    const q = String(query.q).toLowerCase();
    list = list.filter((m) => m.symbol.toLowerCase().includes(q) || m.name.toLowerCase().includes(q));
  }
  if (query.sort === 'gainers') list.sort((a, b) => b.change24h - a.change24h);
  if (query.sort === 'losers') list.sort((a, b) => a.change24h - b.change24h);
  return { markets: list };
});
route('GET', '/api/markets/:symbol', ({ params }) => market.snapshot(market.get(needMarket(params.symbol))));
route('GET', '/api/markets/:symbol/candles', ({ params, query }) => {
  const symbol = needMarket(params.symbol);
  const tf = query.tf || '1D';
  if (!cfg.TIMEFRAMES[tf]) throw new ApiError(400, `tf must be one of ${Object.keys(cfg.TIMEFRAMES).join(', ')}`, 'VALIDATION');
  return { symbol, tf, candles: market.candles(symbol, tf, parseInt(query.limit, 10)) };
});
route('GET', '/api/markets/:symbol/book', ({ params }) => market.book(needMarket(params.symbol)));

// ------------------------------------------------------------------ routes: auth
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
route('POST', '/api/auth/register', { limit: authLimit }, ({ body }) => {
  const email = String(body.email || '').trim().toLowerCase();
  const password = String(body.password || '');
  const name = String(body.name || email.split('@')[0]).trim().slice(0, 60);
  if (!EMAIL_RE.test(email) || email.length > 200) throw new ApiError(400, 'A valid email is required', 'VALIDATION');
  if (password.length < 8 || password.length > 200) throw new ApiError(400, 'Password must be 8-200 characters', 'VALIDATION');
  if (!name) throw new ApiError(400, 'Name is required', 'VALIDATION');
  if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(email)) throw new ApiError(409, 'Email already registered', 'EMAIL_TAKEN');

  const user = tx(() => {
    const id = db.prepare('INSERT INTO users (email,name,password_hash,created_at) VALUES (?,?,?,?)')
      .run(email, name, auth.hashPassword(password), Date.now()).lastInsertRowid;
    if (cfg.STARTING_USD > 0) trading.adjust(id, 'USD', cfg.STARTING_USD);
    const wl = db.prepare('INSERT INTO watchlist (user_id,symbol,created_at) VALUES (?,?,?)');
    for (const s of ['BTC', 'ETH', 'SOL']) wl.run(id, s, Date.now());
    return { id, email, name };
  });
  return created({ token: auth.createSession(user.id), user });
});

route('POST', '/api/auth/login', { limit: authLimit }, ({ body }) => {
  const u = auth.login(body.email, body.password);
  return { token: auth.createSession(u.id), user: { id: u.id, email: u.email, name: u.name } };
});
route('POST', '/api/auth/logout', { auth: true }, ({ req }) => { auth.destroySession(auth.bearer(req)); return { ok: true }; });
route('GET', '/api/me', { auth: true }, ({ user }) => ({ user }));

// ------------------------------------------------------------------ routes: watchlist
route('GET', '/api/watchlist', { auth: true }, ({ user }) => {
  const rows = db.prepare('SELECT symbol FROM watchlist WHERE user_id = ? ORDER BY created_at, symbol').all(user.id);
  return { markets: rows.map((r) => market.snapshot(market.get(r.symbol))) };
});
route('POST', '/api/watchlist', { auth: true }, ({ user, body }) => {
  const symbol = needMarket(body.symbol);
  db.prepare('INSERT OR IGNORE INTO watchlist (user_id,symbol,created_at) VALUES (?,?,?)').run(user.id, symbol, Date.now());
  return { ok: true, symbol };
});
route('DELETE', '/api/watchlist/:symbol', { auth: true }, ({ user, params }) => {
  db.prepare('DELETE FROM watchlist WHERE user_id = ? AND symbol = ?').run(user.id, String(params.symbol).toUpperCase());
  return { ok: true };
});

// ------------------------------------------------------------------ routes: portfolio, orders, positions
route('GET', '/api/portfolio', { auth: true }, ({ user }) => trading.portfolio(user.id));

route('POST', '/api/orders', { auth: true }, ({ user, body }) => created({ order: trading.placeOrder(user.id, body) }));
route('GET', '/api/orders', { auth: true }, ({ user, query }) => ({ orders: trading.listOrders(user.id, query) }));
route('DELETE', '/api/orders/:id', { auth: true }, ({ user, params }) => ({ order: trading.cancelOrder(user.id, Number(params.id)) }));
route('GET', '/api/trades', { auth: true }, ({ user, query }) => ({ trades: trading.listTrades(user.id, query) }));

route('GET', '/api/positions', { auth: true }, ({ user, query }) => ({ positions: trading.listPositions(user.id, query) }));
route('POST', '/api/positions', { auth: true }, ({ user, body }) => created({ position: trading.openPosition(user.id, body) }));
route('POST', '/api/positions/:id/close', { auth: true }, ({ user, params }) => ({ position: trading.closePosition(user.id, Number(params.id)) }));
route('DELETE', '/api/positions/:id', { auth: true }, ({ user, params }) => ({ position: trading.closePosition(user.id, Number(params.id)) }));

// ------------------------------------------------------------------ routes: deposits
route('GET', '/api/deposit-info', () => deposits.info());
route('POST', '/api/deposits', { auth: true }, ({ user, body }) => created({ deposit: deposits.create(user.id, body) }));
route('GET', '/api/deposits', { auth: true }, ({ user }) => ({ deposits: deposits.list(user.id) }));
route('POST', '/api/admin/deposits/:id/confirm', { admin: true }, ({ params }) => ({ deposit: deposits.resolve(Number(params.id), 'confirm') }));
route('POST', '/api/admin/deposits/:id/reject', { admin: true }, ({ params }) => ({ deposit: deposits.resolve(Number(params.id), 'reject') }));

// ------------------------------------------------------------------ http + websocket server
const server = http.createServer(handle);
server.requestTimeout = 15000;

const clients = new Set(); // { conn, userId, symbol }
const sendTo = (c, msg) => c.conn.send(typeof msg === 'string' ? msg : JSON.stringify(msg));

ws.attach(server, {
  path: '/ws',
  onConnection(conn) {
    const c = { conn, userId: null, symbol: 'BTC' };
    clients.add(c);
    sendTo(c, { type: 'hello', markets: market.snapshots() });
    conn.on('close', () => clients.delete(c));
    conn.on('message', (raw) => {
      let m;
      try { m = JSON.parse(raw); } catch { return; }
      if (m.type === 'subscribe' && market.has(String(m.symbol).toUpperCase())) {
        c.symbol = String(m.symbol).toUpperCase();
        sendTo(c, { type: 'book', ...market.book(c.symbol) });
      } else if (m.type === 'auth') {
        const user = auth.userFromToken(m.token);
        c.userId = user ? user.id : null;
        sendTo(c, { type: 'auth', ok: Boolean(user) });
        if (user) sendTo(c, { type: 'portfolio', ...trading.portfolio(user.id) });
      }
    });
  },
});

market.events.on('tick', ({ ts }) => {
  try {
    for (const m of market.list()) trading.processTick(m.symbol);
  } catch (err) {
    console.error('[engine] processTick failed:', err);
  }
  if (!clients.size) return;
  const tickMsg = JSON.stringify({ type: 'tick', ts, markets: market.snapshots() });
  const books = new Map();
  for (const c of clients) {
    sendTo(c, tickMsg);
    if (!books.has(c.symbol)) books.set(c.symbol, JSON.stringify({ type: 'book', ...market.book(c.symbol) }));
    sendTo(c, books.get(c.symbol));
    sendTo(c, { type: 'candle', symbol: c.symbol, candles: market.currentCandles(c.symbol) });
    if (c.userId) sendTo(c, { type: 'portfolio', ...trading.portfolio(c.userId) });
  }
});

function pushToUser(userId, msg) {
  const text = JSON.stringify(msg);
  for (const c of clients) if (c.userId === userId) sendTo(c, text);
}
trading.events.on('order', (userId, order) => pushToUser(userId, { type: 'order', order }));
trading.events.on('position', (userId, position) => pushToUser(userId, { type: 'position', position }));

const heartbeat = setInterval(() => {
  for (const c of clients) {
    if (!c.conn.alive) { c.conn.close(1001); continue; }
    c.conn.alive = false;
    c.conn.ping();
  }
}, 30000);
heartbeat.unref();
setInterval(() => auth.purgeExpired(), 3600e3).unref();

server.listen(cfg.PORT, () => {
  market.start();
  console.log(`[vertex] API  http://localhost:${cfg.PORT}/api/health`);
  console.log(`[vertex] WS   ws://localhost:${cfg.PORT}/ws`);
  if (!cfg.DEPOSIT_BANK_ACCOUNT) console.log('[vertex] deposits disabled (set DEPOSIT_BANK_ACCOUNT to enable)');
  if (!cfg.ADMIN_KEY) console.log('[vertex] admin endpoints disabled (set ADMIN_KEY to enable)');
});

function shutdown() {
  console.log('\n[vertex] shutting down');
  market.stop();
  server.close(() => { db.close(); process.exit(0); });
  setTimeout(() => process.exit(0), 2000).unref();
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

module.exports = { server };
