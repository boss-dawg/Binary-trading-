'use strict';

class ApiError extends Error {
  constructor(status, message, code) {
    super(message);
    this.status = status;
    this.code = code || 'ERROR';
  }
}

const num = (v, name) => {
  const n = typeof v === 'number' ? v : typeof v === 'string' && v.trim() !== '' ? Number(v) : NaN;
  if (!Number.isFinite(n)) throw new ApiError(400, `${name} must be a number`, 'VALIDATION');
  return n;
};
const positive = (v, name, max = 1e12) => {
  const n = num(v, name);
  if (n <= 0 || n > max) throw new ApiError(400, `${name} must be greater than 0`, 'VALIDATION');
  return n;
};

module.exports = { ApiError, num, positive };
