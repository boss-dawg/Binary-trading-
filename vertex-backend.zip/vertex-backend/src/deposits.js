'use strict';
const crypto = require('node:crypto');
const { db, tx } = require('./db');
const cfg = require('./config');
const { adjust, r8 } = require('./trading');
const { ApiError, positive } = require('./errors');

const S = {
  ins: db.prepare(`INSERT INTO deposits (user_id,amount,currency,reference,bank_account,status,created_at)
                   VALUES (?,?,?,?,?,'pending',?)`),
  byId: db.prepare('SELECT * FROM deposits WHERE id = ?'),
  list: db.prepare('SELECT * FROM deposits WHERE user_id = ? ORDER BY id DESC LIMIT 100'),
  resolve: db.prepare('UPDATE deposits SET status = ?, resolved_at = ? WHERE id = ?'),
};

const dto = (r) => ({
  id: r.id, amount: r.amount, currency: r.currency, reference: r.reference,
  status: r.status, createdAt: r.created_at, resolvedAt: r.resolved_at,
});

function info() {
  const enabled = Boolean(cfg.DEPOSIT_BANK_ACCOUNT);
  return {
    enabled,
    currency: cfg.DEPOSIT_CURRENCY,
    bankAccount: enabled ? cfg.DEPOSIT_BANK_ACCOUNT : null,
    bankName: cfg.DEPOSIT_BANK_NAME || null,
    accountName: cfg.DEPOSIT_ACCOUNT_NAME || null,
    instructions: enabled
      ? 'Create a deposit request to get a reference code, transfer the amount to this account and put the reference in the payment description. Your balance is credited once the transfer is confirmed.'
      : 'Deposits are not configured.',
  };
}

function create(userId, input) {
  if (!cfg.DEPOSIT_BANK_ACCOUNT) throw new ApiError(503, 'Deposits are not configured', 'DEPOSITS_DISABLED');
  const amount = positive(input?.amount, 'amount', 1e8);
  if (amount < 1) throw new ApiError(400, 'Minimum deposit is 1', 'VALIDATION');
  const reference = 'VTX-' + crypto.randomBytes(5).toString('hex').toUpperCase();
  const id = S.ins.run(userId, amount, cfg.DEPOSIT_CURRENCY, reference, cfg.DEPOSIT_BANK_ACCOUNT, Date.now()).lastInsertRowid;
  return { ...dto(S.byId.get(id)), bankAccount: cfg.DEPOSIT_BANK_ACCOUNT, bankName: cfg.DEPOSIT_BANK_NAME || null, accountName: cfg.DEPOSIT_ACCOUNT_NAME || null };
}

const list = (userId) => S.list.all(userId).map(dto);

// Admin only: called after the operator has verified the money arrived in the bank account.
function resolve(id, action) {
  return dto(tx(() => {
    const d = S.byId.get(id);
    if (!d) throw new ApiError(404, 'Deposit not found', 'NOT_FOUND');
    if (d.status !== 'pending') throw new ApiError(409, `Deposit is already ${d.status}`, 'NOT_PENDING');
    if (action === 'confirm') adjust(d.user_id, 'USD', r8(d.amount * cfg.DEPOSIT_TO_USD_RATE));
    S.resolve.run(action === 'confirm' ? 'confirmed' : 'rejected', Date.now(), id);
    return S.byId.get(id);
  }));
}

module.exports = { info, create, list, resolve };
